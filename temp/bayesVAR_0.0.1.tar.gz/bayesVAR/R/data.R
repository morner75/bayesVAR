#' Macroeconomic time series data in South Korea
#'
#' A dataset containing quarterly macroeconomic data
#'
#' @format a xts format with 84 rows and 9 variables:
#' \describe{
#' \item{RGDP_Q_G}{real GDP growth, YoY growth}
#' \item{CPI_G}{Consumer Price Index, YoY growth}
#' \item{UNEMP_D}{Unemployment, QoQ difference}
#' \item{USDKRW_G}{Exchage rate USD/KRW, QoQ growth}
#' \item{KOSPI_G}{KOSPI index, QoQ growth}
#' \item{HOUSE_G}{House Price, YoY growth}
#' \item{INT_KTB3Y}{Korea Treasury Bond(3-year), QoQ}
#' \item{INT_CD91}{CD(91-days) rate, QoQ}
#' \item{INT_CALL}{CALL money market rate, QoQ}
#' }
#' @source \url{https://ecos.bok.or.kr/}
"macrodata"
